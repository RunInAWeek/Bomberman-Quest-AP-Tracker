-- put logic functions here using the Lua API: https://github.com/black-sliver/PopTracker/blob/master/doc/PACKS.md#lua-interface
-- don't be afraid to use custom logic functions. it will make many things a lot easier to maintain, for example by adding logging.
-- to see how this function gets called, check: locations/locations.json
-- example:

function has(item, amount)
    local count = Tracker:ProviderCountForCode(item)
    if not amount then
        return count > 0
    else
        amount = tonumber(amount)
        return count >= amount
    end
end

function hasnot(item)
	local count2 = Tracker:ProviderCountForCode(item)
    if count2 > 0 then
		return false
	else return true
	end
end


function canJump()
    return has("shoes_j") or has("wings")
end


function canBombSplash()
    return has("bomb_f") or has("bomb_s") or has("bomb_h")
    or has("bomb_right") or has("bomb_left") or has("bomb_robot")
end

function canHitFlying()
    return has("power_gloves") or canBombSplash() or (has("gauntlets") or has("hammer"))
end

function canKO()
    return has("tackle_belt") or has("gauntlets") or has("hammer")
end

function canHitFollower()
    return canKO() or has("mine")
end

function canPassTiles()
    return has("shoes_d") or canJump() or has("tackle_belt")
end

function canBombThrow()
    return has("power_gloves") and canBombSplash()
end

function canLongTimer()
    return has("bomb_lf") or has("remote")
end

