# Custom items via Lua API

This custom item is using an example from
the [evermizer tracker pack](https://github.com/Cyb3RGER/evermizer-tracker-package).

It creates an extended version of a ``progressive_toggle`` item.

``class.lua`` allows you to create "classes" in lua.

``progressiveTogglePlusWrapper.lua`` creates the wrapper class that has all needed functions to communicate with
PopTracker.

``progressiveTogglePlus.lua`` create the actual class that holds the item state and implements all functions.

more info soon.